"use strict";exports.id=2104,exports.ids=[2104,1188],exports.modules={1188:(t,e,i)=>{function n(t,e={}){let{maxContextTokens:i=4e3,maxContextCharacters:n,maxChunksPerSource:o=3,maxSources:r=5,mergeStrategy:a="concatenate"}=e,s=new Map;for(let e of t){let t=`${e.entityType}:${e.entityId}`;s.has(t)||s.set(t,[]),s.get(t).push(e)}let l=[],c=0,u=0;for(let{key:t,chunks:e}of Array.from(s.entries()).map(([t,e])=>({key:t,chunks:e.sort((t,e)=>e.similarity-t.similarity),bestSimilarity:Math.max(...e.map(t=>t.similarity))})).sort((t,e)=>e.bestSimilarity-t.bestSimilarity).slice(0,r)){let t;if(l.length>=r)break;let s=e.slice(0,o),d=s[0],p=d.metadata,m=(t="concatenate"===a?s.map(t=>t.contentText.trim()).filter(t=>t.length>0).join("\n\n"):s.map(t=>t.contentText.trim()).filter(t=>t.length>0).join("\n\n")).length,f=Math.ceil(m/4);if(n&&c+m>n||u+f>i)break;let h={sourceType:d.entityType,sourceId:d.entityId,title:p.product_title||p.page_title||p.title||void 0,url:p.product_url||p.page_url||p.url||void 0,content:t,chunkIds:s.map(t=>t.id),chunkIndices:s.map(t=>t.chunkIndex),sourceUpdatedAt:p.source_updated_at||void 0,similarity:Math.max(...s.map(t=>t.similarity))};l.push(h),c+=m,u+=f}return l}function o(t){return 0===t.length?"":t.map((t,e)=>{let i=[`[Source ${e+1}]`,t.title?`Title: ${t.title}`:null,t.url?`URL: ${t.url}`:null,t.sourceUpdatedAt?`Updated: ${new Date(t.sourceUpdatedAt).toLocaleDateString()}`:null].filter(Boolean).join(" | ");return`${i}
${t.content}`}).join("\n\n---\n\n")}i.d(e,{J:()=>o,buildContextBlocks:()=>n})},2104:(t,e,i)=>{i.d(e,{assemblePrompt:()=>r});var n=i(1188);let o=`You are a helpful AI assistant for an e-commerce store. Your role is to answer customer questions about products, policies, and store information.

Guidelines:
- Provide accurate, helpful information based on the context provided
- If you don't know something, say so rather than guessing
- Be friendly and professional
- When mentioning products, include relevant details like price, availability, and features
- For policy questions (shipping, returns, etc.), refer to the specific policy information provided
- Always cite your sources when referencing specific information

Use the context provided below to answer questions. If the context doesn't contain relevant information, you can still provide general assistance but indicate that you don't have specific information about that topic.`;function r(t,e=[],i={}){let{systemTemplate:r=o,includeContext:a=!0,contextPrefix:s="Context:",userMessagePrefix:l="User Question:"}=i,c=r;if(a&&e.length>0){let t=(0,n.J)(e);c+=`

${s}
${t}`}let u=`${l}
${t}`,d=`${c}

${u}`;return{systemPrompt:c,userPrompt:u,fullPrompt:d}}}};