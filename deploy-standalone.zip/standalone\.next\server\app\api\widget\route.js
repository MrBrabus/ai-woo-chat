"use strict";(()=>{var e={};e.id=8356,e.ids=[8356],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4904:(e,t,n)=>{n.r(t),n.d(t,{headerHooks:()=>h,originalPathname:()=>f,patchFetch:()=>y,requestAsyncStorage:()=>p,routeModule:()=>c,serverHooks:()=>g,staticGenerationAsyncStorage:()=>u,staticGenerationBailout:()=>m});var i={};n.r(i),n.d(i,{GET:()=>d,OPTIONS:()=>l});var o=n(5419),r=n(9108),s=n(9678),a=n(8070);async function l(e){return new a.Z(null,{status:200,headers:{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Accept","Access-Control-Max-Age":"86400"}})}async function d(e){let t={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET, OPTIONS","Access-Control-Allow-Headers":"Content-Type, Accept","Cross-Origin-Resource-Policy":"cross-origin"};try{let n=`
      (function() {
        'use strict';
        
        // Suppress React errors if React is not available (we don't use React)
        const originalError = console.error;
        console.error = function(...args) {
          const message = args[0]?.toString() || '';
          if (message.includes('__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED') || 
              message.includes('React') || 
              message.includes('zb is undefined')) {
            // Ignore React-related errors (not our code)
            return;
          }
          originalError.apply(console, args);
        };
        
        // Check if widget container already exists and has content
        const existingContainer = document.getElementById('ai-woo-chat-widget-container');
        if (existingContainer) {
          // Widget already rendered
          return;
        }
        
        const CONFIG = window.AIWooChatConfig || {};
        const SAAS_URL = CONFIG.saasUrl || '';
        const SITE_ID = CONFIG.siteId || '';
        
        if (!SAAS_URL || !SITE_ID) {
          return;
        }
        
        // Initialize widget immediately (no React dependencies needed for minimal version)
        const initWidget = () => {
          console.log('AI Woo Chat: initWidget called');
          const container = document.getElementById('ai-woo-chat-widget');
          if (!container) {
            // If container doesn't exist, create it
            const newContainer = document.createElement('div');
            newContainer.id = 'ai-woo-chat-widget';
            document.body.appendChild(newContainer);
            initMinimalWidget(newContainer);
            return;
          }
          
          // Check if widget is already rendered in container
          const existingWidget = container.querySelector('#ai-woo-chat-widget-container');
          if (existingWidget) {
            return;
          }
          
          // For now, use minimal widget that works immediately
          // TODO: In production, load the full React widget bundle
          initMinimalWidget(container);
        };
        
        // Minimal widget fallback (works without external dependencies)
        const initMinimalWidget = (container) => {
          console.log('AI Woo Chat: initMinimalWidget called, container:', container);
          if (!container) {
            console.error('AI Woo Chat: initMinimalWidget - container is null');
            return;
          }
          
          // Load the actual widget bundle from Next.js build
          // For now, we'll create a minimal working widget
          const widgetHTML = \`
            <div id="ai-woo-chat-widget-container" style="position:fixed;bottom:24px;right:24px;z-index:9998;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif;">
              <div id="ai-woo-chat-window" style="display:none;width:380px;height:600px;max-width:calc(100vw - 48px);max-height:calc(100vh - 96px);background:white;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.12);flex-direction:column;margin-bottom:12px;">
                <div style="background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);color:white;padding:16px 20px;border-radius:12px 12px 0 0;display:flex;justify-content:space-between;align-items:center;">
                  <h3 style="margin:0;font-size:16px;font-weight:600;">AI Assistant</h3>
                  <button id="ai-woo-chat-close" style="background:none;border:none;color:white;font-size:24px;cursor:pointer;padding:0;width:28px;height:28px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:background 0.2s;" onmouseover="this.style.background='rgba(255,255,255,0.2)'" onmouseout="this.style.background='none'">\xd7</button>
                </div>
                <div id="ai-woo-chat-messages" style="flex:1;padding:20px;overflow-y:auto;height:450px;background:#f8f9fa;">
                  <div style="background:white;padding:12px 16px;border-radius:8px;margin-bottom:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <p style="margin:0;color:#495057;font-size:14px;line-height:1.5;">Hello! I'm your AI assistant. How can I help you today?</p>
                  </div>
                </div>
                <div style="padding:16px;border-top:1px solid #e9ecef;background:white;border-radius:0 0 12px 12px;">
                  <div style="display:flex;gap:8px;">
                    <input type="text" id="ai-woo-chat-input" placeholder="Type your message..." style="flex:1;padding:10px 14px;border:1px solid #dee2e6;border-radius:8px;box-sizing:border-box;font-size:14px;outline:none;transition:border-color 0.2s;" onfocus="this.style.borderColor='#667eea'" onblur="this.style.borderColor='#dee2e6'">
                    <button id="ai-woo-chat-send" style="background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);color:white;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;font-size:14px;font-weight:500;transition:transform 0.2s,box-shadow 0.2s;" onmouseover="this.style.transform='translateY(-1px)';this.style.boxShadow='0 4px 12px rgba(102,126,234,0.4)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">Send</button>
                  </div>
                </div>
              </div>
              <button id="ai-woo-chat-toggle" style="width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg, #667eea 0%, #764ba2 100%);border:none;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.15);display:flex;align-items:center;justify-content:center;color:white;transition:transform 0.2s ease,box-shadow 0.2s ease;" onmouseover="this.style.transform='scale(1.1)';this.style.boxShadow='0 6px 16px rgba(0,0,0,0.2)'" onmouseout="this.style.transform='scale(1)';this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z" fill="currentColor"/>
                </svg>
              </button>
            </div>
          \`;
          
          // Set innerHTML directly
          console.log('AI Woo Chat: Setting innerHTML, widgetHTML length:', widgetHTML.length);
          container.innerHTML = widgetHTML;
          console.log('AI Woo Chat: innerHTML set, container now has:', container.innerHTML.substring(0, 100));
          
          // Add click handlers
          const toggleBtn = document.getElementById('ai-woo-chat-toggle');
          const closeBtn = document.getElementById('ai-woo-chat-close');
          const chatWindow = document.getElementById('ai-woo-chat-window');
          const sendBtn = document.getElementById('ai-woo-chat-send');
          const input = document.getElementById('ai-woo-chat-input');
          const messagesDiv = document.getElementById('ai-woo-chat-messages');
          
          if (toggleBtn && chatWindow) {
            toggleBtn.addEventListener('click', function() {
              if (chatWindow.style.display === 'none' || !chatWindow.style.display) {
                chatWindow.style.display = 'flex';
                toggleBtn.style.display = 'none';
                if (input) input.focus();
              } else {
                chatWindow.style.display = 'none';
                toggleBtn.style.display = 'block';
              }
            });
          }
          
          if (closeBtn && chatWindow && toggleBtn) {
            closeBtn.addEventListener('click', function() {
              chatWindow.style.display = 'none';
              toggleBtn.style.display = 'block';
            });
          }
          
          const sendMessage = function() {
            if (!input || !messagesDiv) return;
            const message = input.value.trim();
            if (!message) return;
            
            // Add user message
            const userMsg = document.createElement('div');
            userMsg.style.cssText = 'background:#667eea;color:white;padding:12px 16px;border-radius:8px;margin-bottom:12px;margin-left:40px;box-shadow:0 1px 3px rgba(0,0,0,0.1);';
            const msgP = document.createElement('p');
            msgP.style.cssText = 'margin:0;font-size:14px;line-height:1.5;';
            msgP.textContent = message;
            userMsg.appendChild(msgP);
            messagesDiv.appendChild(userMsg);
            
            input.value = '';
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
            
            // Note: This is a minimal fallback - full functionality requires the React widget
            setTimeout(function() {
              const assistantMsg = document.createElement('div');
              assistantMsg.style.cssText = 'background:white;padding:12px 16px;border-radius:8px;margin-bottom:12px;box-shadow:0 1px 3px rgba(0,0,0,0.1);';
              assistantMsg.innerHTML = '<p style="margin:0;color:#495057;font-size:14px;line-height:1.5;">I'm a minimal fallback widget. The full widget is still loading. Please refresh the page to try again.</p>';
              messagesDiv.appendChild(assistantMsg);
              messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }, 500);
          };
          
          if (sendBtn) {
            sendBtn.addEventListener('click', sendMessage);
          }
          
          if (input) {
            input.addEventListener('keypress', function(e) {
              if (e.key === 'Enter') {
                sendMessage();
              }
            });
          }
          
          window.AIWooChatWidget = { initialized: true, fallback: true };
        };
        
        // Initialize widget when DOM is ready
        // Use setTimeout to ensure this runs after WordPress inline loader
        setTimeout(function() {
          if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', function() {
              console.log('AI Woo Chat: DOMContentLoaded, calling initWidget');
              initWidget();
            });
          } else {
            // DOM is already ready
            console.log('AI Woo Chat: DOM ready, calling initWidget immediately');
            initWidget();
          }
        }, 100);
      })();
    `;e.headers.get("origin");let i=new Headers({"Content-Type":"application/javascript; charset=utf-8","Cache-Control":"public, max-age=86400, s-maxage=86400, immutable",...t,"X-Content-Type-Options":"nosniff"});return new a.Z(n,{headers:i})}catch(e){return new a.Z(`// Widget bundle error: ${e instanceof Error?e.message:"Unknown error"}`,{status:200,headers:{"Content-Type":"application/javascript; charset=utf-8",...t,"X-Content-Type-Options":"nosniff"}})}}let c=new o.AppRouteRouteModule({definition:{kind:r.x.APP_ROUTE,page:"/api/widget/route",pathname:"/api/widget",filename:"route",bundlePath:"app/api/widget/route"},resolvedPagePath:"C:\\xampp\\htdocs\\AI Woo Chat\\src\\app\\api\\widget\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:p,staticGenerationAsyncStorage:u,serverHooks:g,headerHooks:h,staticGenerationBailout:m}=c,f="/api/widget/route";function y(){return(0,s.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:u})}},7347:e=>{var t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,o=Object.prototype.hasOwnProperty,r={};function s(e){var t;let n=["path"in e&&e.path&&`Path=${e.path}`,"expires"in e&&(e.expires||0===e.expires)&&`Expires=${("number"==typeof e.expires?new Date(e.expires):e.expires).toUTCString()}`,"maxAge"in e&&"number"==typeof e.maxAge&&`Max-Age=${e.maxAge}`,"domain"in e&&e.domain&&`Domain=${e.domain}`,"secure"in e&&e.secure&&"Secure","httpOnly"in e&&e.httpOnly&&"HttpOnly","sameSite"in e&&e.sameSite&&`SameSite=${e.sameSite}`,"priority"in e&&e.priority&&`Priority=${e.priority}`].filter(Boolean);return`${e.name}=${encodeURIComponent(null!=(t=e.value)?t:"")}; ${n.join("; ")}`}function a(e){let t=new Map;for(let n of e.split(/; */)){if(!n)continue;let e=n.indexOf("=");if(-1===e){t.set(n,"true");continue}let[i,o]=[n.slice(0,e),n.slice(e+1)];try{t.set(i,decodeURIComponent(null!=o?o:"true"))}catch{}}return t}function l(e){var t,n;if(!e)return;let[[i,o],...r]=a(e),{domain:s,expires:l,httponly:p,maxage:u,path:g,samesite:h,secure:m,priority:f}=Object.fromEntries(r.map(([e,t])=>[e.toLowerCase(),t]));return function(e){let t={};for(let n in e)e[n]&&(t[n]=e[n]);return t}({name:i,value:decodeURIComponent(o),domain:s,...l&&{expires:new Date(l)},...p&&{httpOnly:!0},..."string"==typeof u&&{maxAge:Number(u)},path:g,...h&&{sameSite:d.includes(t=(t=h).toLowerCase())?t:void 0},...m&&{secure:!0},...f&&{priority:c.includes(n=(n=f).toLowerCase())?n:void 0}})}((e,n)=>{for(var i in n)t(e,i,{get:n[i],enumerable:!0})})(r,{RequestCookies:()=>p,ResponseCookies:()=>u,parseCookie:()=>a,parseSetCookie:()=>l,stringifyCookie:()=>s}),e.exports=((e,r,s,a)=>{if(r&&"object"==typeof r||"function"==typeof r)for(let s of i(r))o.call(e,s)||void 0===s||t(e,s,{get:()=>r[s],enumerable:!(a=n(r,s))||a.enumerable});return e})(t({},"__esModule",{value:!0}),r);var d=["strict","lax","none"],c=["low","medium","high"],p=class{constructor(e){this._parsed=new Map,this._headers=e;let t=e.get("cookie");if(t)for(let[e,n]of a(t))this._parsed.set(e,{name:e,value:n})}[Symbol.iterator](){return this._parsed[Symbol.iterator]()}get size(){return this._parsed.size}get(...e){let t="string"==typeof e[0]?e[0]:e[0].name;return this._parsed.get(t)}getAll(...e){var t;let n=Array.from(this._parsed);if(!e.length)return n.map(([e,t])=>t);let i="string"==typeof e[0]?e[0]:null==(t=e[0])?void 0:t.name;return n.filter(([e])=>e===i).map(([e,t])=>t)}has(e){return this._parsed.has(e)}set(...e){let[t,n]=1===e.length?[e[0].name,e[0].value]:e,i=this._parsed;return i.set(t,{name:t,value:n}),this._headers.set("cookie",Array.from(i).map(([e,t])=>s(t)).join("; ")),this}delete(e){let t=this._parsed,n=Array.isArray(e)?e.map(e=>t.delete(e)):t.delete(e);return this._headers.set("cookie",Array.from(t).map(([e,t])=>s(t)).join("; ")),n}clear(){return this.delete(Array.from(this._parsed.keys())),this}[Symbol.for("edge-runtime.inspect.custom")](){return`RequestCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`}toString(){return[...this._parsed.values()].map(e=>`${e.name}=${encodeURIComponent(e.value)}`).join("; ")}},u=class{constructor(e){var t,n,i;this._parsed=new Map,this._headers=e;let o=null!=(i=null!=(n=null==(t=e.getSetCookie)?void 0:t.call(e))?n:e.get("set-cookie"))?i:[];for(let e of Array.isArray(o)?o:function(e){if(!e)return[];var t,n,i,o,r,s=[],a=0;function l(){for(;a<e.length&&/\s/.test(e.charAt(a));)a+=1;return a<e.length}for(;a<e.length;){for(t=a,r=!1;l();)if(","===(n=e.charAt(a))){for(i=a,a+=1,l(),o=a;a<e.length&&"="!==(n=e.charAt(a))&&";"!==n&&","!==n;)a+=1;a<e.length&&"="===e.charAt(a)?(r=!0,a=o,s.push(e.substring(t,i)),t=a):a=i+1}else a+=1;(!r||a>=e.length)&&s.push(e.substring(t,e.length))}return s}(o)){let t=l(e);t&&this._parsed.set(t.name,t)}}get(...e){let t="string"==typeof e[0]?e[0]:e[0].name;return this._parsed.get(t)}getAll(...e){var t;let n=Array.from(this._parsed.values());if(!e.length)return n;let i="string"==typeof e[0]?e[0]:null==(t=e[0])?void 0:t.name;return n.filter(e=>e.name===i)}has(e){return this._parsed.has(e)}set(...e){let[t,n,i]=1===e.length?[e[0].name,e[0].value,e[0]]:e,o=this._parsed;return o.set(t,function(e={name:"",value:""}){return"number"==typeof e.expires&&(e.expires=new Date(e.expires)),e.maxAge&&(e.expires=new Date(Date.now()+1e3*e.maxAge)),(null===e.path||void 0===e.path)&&(e.path="/"),e}({name:t,value:n,...i})),function(e,t){for(let[,n]of(t.delete("set-cookie"),e)){let e=s(n);t.append("set-cookie",e)}}(o,this._headers),this}delete(...e){let[t,n,i]="string"==typeof e[0]?[e[0]]:[e[0].name,e[0].path,e[0].domain];return this.set({name:t,path:n,domain:i,value:"",expires:new Date(0)})}[Symbol.for("edge-runtime.inspect.custom")](){return`ResponseCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`}toString(){return[...this._parsed.values()].map(s).join("; ")}}},3608:(e,t,n)=>{Object.defineProperty(t,"__esModule",{value:!0}),function(e,t){for(var n in t)Object.defineProperty(e,n,{enumerable:!0,get:t[n]})}(t,{RequestCookies:function(){return i.RequestCookies},ResponseCookies:function(){return i.ResponseCookies}});let i=n(7347)}};var t=require("../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),i=t.X(0,[1638,6206],()=>n(4904));module.exports=i})();