"use strict";(()=>{var e={};e.id=5971,e.ids=[5971],e.modules={2934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},4580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},5869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4320:(e,t,s)=>{s.r(t),s.d(t,{headerHooks:()=>m,originalPathname:()=>g,patchFetch:()=>I,requestAsyncStorage:()=>u,routeModule:()=>_,serverHooks:()=>v,staticGenerationAsyncStorage:()=>l,staticGenerationBailout:()=>p});var r={};s.r(r),s.d(r,{GET:()=>d});var i=s(5419),a=s(9108),o=s(9678),n=s(8070),c=s(2509);async function d(e,{params:t}){try{let s=await (0,c.e)(),{data:{user:r},error:i}=await s.auth.getUser();if(i||!r)return n.Z.json({error:{code:"UNAUTHORIZED",message:"Authentication required"}},{status:401});let a=new URL(e.url).searchParams.get("site_id"),o=t.conversationId;if(!a)return n.Z.json({error:{code:"MISSING_REQUIRED_FIELD",message:"site_id is required"}},{status:400});let d=(0,c.createAdminClient)(),{data:_,error:u}=await d.from("sites").select("tenant_id").eq("id",a).single();if(u||!_)return n.Z.json({error:{code:"SITE_NOT_FOUND",message:"Site not found"}},{status:404});let l=null,v=null,{data:m,error:p}=await d.from("conversations").select(`
        id,
        conversation_id,
        site_id,
        visitor_id,
        last_message_at,
        message_count,
        created_at,
        visitors!inner (
          visitor_id,
          first_seen_at,
          last_seen_at
        )
      `).eq("site_id",a).eq("id",o).single();if(m&&!p)l=m;else{let{data:e,error:t}=await d.from("conversations").select(`
          id,
          conversation_id,
          site_id,
          visitor_id,
          last_message_at,
          message_count,
          created_at,
          visitors!inner (
            visitor_id,
            first_seen_at,
            last_seen_at
          )
        `).eq("site_id",a).eq("conversation_id",o).single();l=e,v=t}if(v||!l)return n.Z.json({error:{code:"CONVERSATION_NOT_FOUND",message:"Conversation not found"}},{status:404});let{data:g,error:I}=await d.from("messages").select("*").eq("conversation_id",l.id).order("created_at",{ascending:!0});if(I)throw I;let f={id:l.id,conversation_id:l.conversation_id,site_id:l.site_id,visitor_id:l.visitor_id,last_message_at:l.last_message_at,message_count:l.message_count||0,created_at:l.created_at,visitor:l.visitors?{visitor_id:l.visitors.visitor_id,first_seen_at:l.visitors.first_seen_at,last_seen_at:l.visitors.last_seen_at}:null,messages:(g||[]).map(e=>({id:e.id,role:e.role,content_text:e.content_text,content_json:e.content_json,token_usage:e.token_usage,created_at:e.created_at,metadata:e.metadata}))};return n.Z.json(f)}catch(e){return console.error("Conversation GET error:",e),n.Z.json({error:{code:"INTERNAL_ERROR",message:e instanceof Error?e.message:"Failed to fetch conversation"}},{status:500})}}let _=new i.AppRouteRouteModule({definition:{kind:a.x.APP_ROUTE,page:"/api/conversations/[conversationId]/route",pathname:"/api/conversations/[conversationId]",filename:"route",bundlePath:"app/api/conversations/[conversationId]/route"},resolvedPagePath:"C:\\xampp\\htdocs\\AI Woo Chat\\src\\app\\api\\conversations\\[conversationId]\\route.ts",nextConfigOutput:"standalone",userland:r}),{requestAsyncStorage:u,staticGenerationAsyncStorage:l,serverHooks:v,headerHooks:m,staticGenerationBailout:p}=_,g="/api/conversations/[conversationId]/route";function I(){return(0,o.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:l})}},2509:(e,t,s)=>{s.d(t,{createAdminClient:()=>n,e:()=>o});var r=s(6874),i=s(7439),a=s(3950);async function o(){let e=await (0,i.cookies)();return(0,r.lx)("https://drmuwsxyvvfivdfsyydy.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRybXV3c3h5dnZmaXZkZnN5eWR5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg0NjAwMDgsImV4cCI6MjA4NDAzNjAwOH0.kMsFG-VLNqwzIgl3cFW-owiRCWHcB47M6V6Ti4O4alY",{cookies:{get:t=>e.get(t)?.value,set(t,s,r){try{e.set({name:t,value:s,...r})}catch(e){}},remove(t,s){try{e.set({name:t,value:"",...s})}catch(e){}}}})}function n(){return(0,a.eI)("https://drmuwsxyvvfivdfsyydy.supabase.co",process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{autoRefreshToken:!1,persistSession:!1}})}}};var t=require("../../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[1638,9989,6206],()=>s(4320));module.exports=r})();